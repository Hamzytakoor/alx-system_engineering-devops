this is a shell readme
