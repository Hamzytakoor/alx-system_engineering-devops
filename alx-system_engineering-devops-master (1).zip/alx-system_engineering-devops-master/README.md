#!/bin/bash
bash script
