#!/bin/bash
my life as a programmer
