my little program
